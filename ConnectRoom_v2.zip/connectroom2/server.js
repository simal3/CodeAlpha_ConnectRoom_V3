'use strict';

const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const session    = require('express-session');
const bcrypt     = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const multer     = require('multer');
const path       = require('path');

// ─────────────────────────────────────────────
//  APP SETUP
// ─────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server, {
  maxHttpBufferSize: 50e6,          // allow 50 MB socket messages (file chunks)
  pingTimeout:  60000,
  pingInterval: 25000
});
const PORT = process.env.PORT || 3000;

// ─────────────────────────────────────────────
//  IN-MEMORY DATABASE  (no external DB needed)
// ─────────────────────────────────────────────
const DB = {
  users:    new Map(),   // username (lower) → userObj
  rooms:    new Map(),   // roomId           → roomObj
  messages: new Map(),   // roomId           → [msgObj]
  files:    new Map(),   // roomId           → [fileObj]
  sockets:  new Map()    // socketId         → { user, roomId }
};

// ─────────────────────────────────────────────
//  SESSION (shared with Socket.io)
// ─────────────────────────────────────────────
const sessionMW = session({
  secret:            'cr_secret_key_2024',
  resave:            false,
  saveUninitialized: false,
  cookie:            { maxAge: 8 * 60 * 60 * 1000, httpOnly: true }
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(sessionMW);
app.use(express.static(path.join(__dirname, 'public')));

// Socket.io also gets the session
io.use((socket, next) => sessionMW(socket.request, socket.request.res || {}, next));

// ─────────────────────────────────────────────
//  FILE UPLOAD (multer – memory storage)
// ─────────────────────────────────────────────
const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 50 * 1024 * 1024 }
});

// ─────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session && req.session.user) return next();
  res.status(401).json({ error: 'Not authenticated' });
}

function makeRoomId() {
  // 6-char uppercase alphanumeric, easy to type
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

// Seed two demo accounts on startup
function seedDemoUsers() {
  const demos = [
    { username: 'alice', displayName: 'Alice Johnson', password: 'demo1234' },
    { username: 'bob',   displayName: 'Bob Smith',     password: 'demo1234' }
  ];
  demos.forEach(u => {
    if (!DB.users.has(u.username)) {
      DB.users.set(u.username, {
        id:          uuidv4(),
        username:    u.username,
        displayName: u.displayName,
        password:    bcrypt.hashSync(u.password, 10)
      });
    }
  });
}

// ─────────────────────────────────────────────
//  PAGE ROUTES
// ─────────────────────────────────────────────
app.get('/', (req, res) => {
  if (req.session.user) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
app.get('/dashboard', (req, res) => {
  if (!req.session.user) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});
app.get('/room/:roomId', (req, res) => {
  if (!req.session.user) return res.redirect('/');
  res.sendFile(path.join(__dirname, 'public', 'room.html'));
});

// ─────────────────────────────────────────────
//  AUTH API
// ─────────────────────────────────────────────
app.post('/api/register', (req, res) => {
  const { username, password, displayName } = req.body;
  if (!username || !password)
    return res.status(400).json({ error: 'Username and password are required.' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Password must be at least 6 characters.' });

  const key = username.trim().toLowerCase();
  if (DB.users.has(key))
    return res.status(409).json({ error: 'Username already taken.' });

  const user = {
    id:          uuidv4(),
    username:    key,
    displayName: (displayName || username).trim(),
    password:    bcrypt.hashSync(password, 10)
  };
  DB.users.set(key, user);
  req.session.user = { id: user.id, username: user.username, displayName: user.displayName };
  res.json({ ok: true, user: req.session.user });
});

app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const key  = (username || '').trim().toLowerCase();
  const user = DB.users.get(key);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: 'Invalid username or password.' });

  req.session.user = { id: user.id, username: user.username, displayName: user.displayName };
  res.json({ ok: true, user: req.session.user });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => {
  if (!req.session.user) return res.status(401).json({ user: null });
  res.json({ user: req.session.user });
});

// ─────────────────────────────────────────────
//  ROOM API
// ─────────────────────────────────────────────
app.post('/api/rooms', requireAuth, (req, res) => {
  let roomId = makeRoomId();
  // Guarantee uniqueness
  while (DB.rooms.has(roomId)) roomId = makeRoomId();

  const room = {
    id:           roomId,
    name:         (req.body.name || '').trim() || `Room ${roomId}`,
    host:         req.session.user.username,
    participants: [],                          // { username, displayName, socketId }
    createdAt:    new Date().toISOString()
  };
  DB.rooms.set(roomId, room);
  DB.messages.set(roomId, []);
  DB.files.set(roomId, []);

  res.json({ room: { id: room.id, name: room.name, host: room.host } });
});

app.get('/api/rooms/:roomId', (req, res) => {
  const room = DB.rooms.get(req.params.roomId.toUpperCase());
  if (!room) return res.status(404).json({ error: 'Room not found.' });
  res.json({ room: { id: room.id, name: room.name, host: room.host } });
});

// ─────────────────────────────────────────────
//  FILE API
// ─────────────────────────────────────────────
app.post('/api/rooms/:roomId/upload', requireAuth, upload.single('file'), (req, res) => {
  const roomId = req.params.roomId.toUpperCase();
  if (!DB.rooms.has(roomId))
    return res.status(404).json({ error: 'Room not found.' });
  if (!req.file)
    return res.status(400).json({ error: 'No file received.' });

  const fileObj = {
    id:         uuidv4(),
    name:       req.file.originalname,
    size:       req.file.size,
    mimeType:   req.file.mimetype,
    data:       req.file.buffer.toString('base64'),   // stored as base64
    uploader:   req.session.user.displayName,
    uploadedAt: new Date().toISOString()
  };
  DB.files.get(roomId).push(fileObj);

  // Tell everyone in the room a new file is available
  io.to(roomId).emit('file-added', {
    id:         fileObj.id,
    name:       fileObj.name,
    size:       fileObj.size,
    mimeType:   fileObj.mimeType,
    uploader:   fileObj.uploader,
    uploadedAt: fileObj.uploadedAt
  });

  res.json({ ok: true, fileId: fileObj.id, name: fileObj.name });
});

app.get('/api/rooms/:roomId/files/:fileId', requireAuth, (req, res) => {
  const roomId = req.params.roomId.toUpperCase();
  const files  = DB.files.get(roomId) || [];
  const file   = files.find(f => f.id === req.params.fileId);
  if (!file) return res.status(404).json({ error: 'File not found.' });

  const buf = Buffer.from(file.data, 'base64');
  res.setHeader('Content-Type', file.mimeType || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(file.name)}"`);
  res.setHeader('Content-Length', buf.length);
  res.send(buf);
});

// ─────────────────────────────────────────────
//  SOCKET.IO  –  WebRTC signalling + real-time
// ─────────────────────────────────────────────
io.on('connection', (socket) => {
  /* ── authenticate ── */
  const user = socket.request.session && socket.request.session.user;
  if (!user) {
    socket.emit('auth-error', { message: 'Not authenticated. Please log in.' });
    socket.disconnect(true);
    return;
  }

  DB.sockets.set(socket.id, { user, roomId: null });
  console.log(`[+] ${user.displayName}  (${socket.id})`);

  // ── JOIN ROOM ─────────────────────────────
  socket.on('join-room', ({ roomId }) => {
    if (!roomId) return;
    roomId = roomId.toUpperCase();

    const room = DB.rooms.get(roomId);
    if (!room) {
      socket.emit('room-error', { message: 'Room not found. Please check the code.' });
      return;
    }

    // Remove stale entry for same user if any
    room.participants = room.participants.filter(p => p.username !== user.username);

    const participant = { username: user.username, displayName: user.displayName, socketId: socket.id };
    room.participants.push(participant);
    DB.sockets.get(socket.id).roomId = roomId;

    socket.join(roomId);

    /* Send the new joiner the full room state */
    const safeFiles = (DB.files.get(roomId) || []).map(f => ({
      id: f.id, name: f.name, size: f.size,
      mimeType: f.mimeType, uploader: f.uploader, uploadedAt: f.uploadedAt
    }));

    socket.emit('room-joined', {
      room:         { id: room.id, name: room.name, host: room.host },
      participants: room.participants
                        .filter(p => p.socketId !== socket.id)   // exclude self
                        .map(p => ({ username: p.username, displayName: p.displayName, socketId: p.socketId })),
      messages:     DB.messages.get(roomId) || [],
      files:        safeFiles
    });

    /* Tell everyone else */
    socket.to(roomId).emit('peer-joined', {
      username:    user.username,
      displayName: user.displayName,
      socketId:    socket.id
    });

    console.log(`  >> ${user.displayName} joined room ${roomId} (${room.participants.length} total)`);
  });

  // ── WEBRTC SIGNALLING ─────────────────────
  // Relay offer to a specific peer
  socket.on('rtc-offer', ({ to, offer }) => {
    const sender = DB.sockets.get(socket.id);
    io.to(to).emit('rtc-offer', {
      from:        socket.id,
      displayName: sender?.user?.displayName || 'Unknown',
      offer
    });
  });

  // Relay answer back to offerer
  socket.on('rtc-answer', ({ to, answer }) => {
    io.to(to).emit('rtc-answer', { from: socket.id, answer });
  });

  // Relay ICE candidates
  socket.on('rtc-ice', ({ to, candidate }) => {
    io.to(to).emit('rtc-ice', { from: socket.id, candidate });
  });

  // ── CHAT ─────────────────────────────────
  socket.on('chat-send', ({ roomId, text, encrypted }) => {
    if (!roomId || !text) return;
    roomId = roomId.toUpperCase();

    const msg = {
      id:        uuidv4(),
      sender:    user.displayName,
      username:  user.username,
      text,
      encrypted: !!encrypted,
      ts:        new Date().toISOString()
    };
    (DB.messages.get(roomId) || []).push(msg);

    // Broadcast to ALL in room (including sender so they see their own msg)
    io.to(roomId).emit('chat-recv', msg);
  });

  // ── WHITEBOARD ───────────────────────────
  socket.on('wb-draw',  ({ roomId, data })  => socket.to(roomId.toUpperCase()).emit('wb-draw',  { from: socket.id, data }));
  socket.on('wb-clear', ({ roomId })         => socket.to(roomId.toUpperCase()).emit('wb-clear'));
  socket.on('wb-undo',  ({ roomId })         => socket.to(roomId.toUpperCase()).emit('wb-undo'));

  // ── MEDIA STATE ──────────────────────────
  // Let peers know about mic/cam/screen changes
  socket.on('media-update', ({ roomId, audio, video, screen }) => {
    socket.to(roomId.toUpperCase()).emit('peer-media', {
      socketId: socket.id,
      audio, video, screen
    });
  });

  // ── DISCONNECT ───────────────────────────
  socket.on('disconnect', (reason) => {
    const entry = DB.sockets.get(socket.id);
    if (entry && entry.roomId) {
      const room = DB.rooms.get(entry.roomId);
      if (room) {
        room.participants = room.participants.filter(p => p.socketId !== socket.id);
        io.to(entry.roomId).emit('peer-left', {
          socketId:    socket.id,
          displayName: entry.user.displayName
        });
      }
    }
    DB.sockets.delete(socket.id);
    console.log(`[-] ${entry?.user?.displayName} disconnected (${reason})`);
  });
});

// ─────────────────────────────────────────────
//  START
// ─────────────────────────────────────────────
seedDemoUsers();
server.listen(PORT, () => {
  console.log('\n======================================');
  console.log(`  ConnectRoom  →  http://localhost:${PORT}`);
  console.log('  Demo: alice/demo1234  |  bob/demo1234');
  console.log('======================================\n');
});
