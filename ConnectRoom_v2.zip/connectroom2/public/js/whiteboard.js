/**
 * Collaborative Whiteboard
 * Tools: pen, eraser, line, rect, circle
 * All draw events are broadcast via the room socket (set in room.js)
 */
const Whiteboard = (() => {
  let canvas, ctx;
  let tool    = 'pen';
  let color   = '#4f46e5';
  let size    = 4;
  let drawing = false;
  let sx, sy;          // start coords for shapes
  let snap;            // ImageData snapshot for shape preview
  let history = [];    // array of ImageData for undo

  // Injected by room.js after socket is ready
  let _emitDraw, _emitClear, _emitUndo;

  /* ── public init ─────────────────────── */
  function init(canvasEl, emitDraw, emitClear, emitUndo) {
    canvas     = canvasEl;
    ctx        = canvas.getContext('2d');
    _emitDraw  = emitDraw;
    _emitClear = emitClear;
    _emitUndo  = emitUndo;

    resize();
    window.addEventListener('resize', resize);

    canvas.addEventListener('mousedown',  onDown);
    canvas.addEventListener('mousemove',  onMove);
    canvas.addEventListener('mouseup',    onUp);
    canvas.addEventListener('mouseleave', onUp);

    // Touch
    canvas.addEventListener('touchstart',  e => { e.preventDefault(); onDown(e.touches[0]); }, { passive: false });
    canvas.addEventListener('touchmove',   e => { e.preventDefault(); onMove(e.touches[0]); }, { passive: false });
    canvas.addEventListener('touchend',    e => { e.preventDefault(); onUp();               }, { passive: false });

    fill('#ffffff');
    save();
  }

  function resize() {
    if (!canvas) return;
    const prev = canvas.width > 0 ? ctx.getImageData(0,0,canvas.width,canvas.height) : null;
    canvas.width  = canvas.parentElement.clientWidth  || 800;
    canvas.height = (canvas.parentElement.clientHeight || 500) - 52; // minus toolbar
    fill('#ffffff');
    if (prev) ctx.putImageData(prev, 0, 0);
    history = [];
    save();
  }

  function fill(c) { ctx.fillStyle = c; ctx.fillRect(0,0,canvas.width,canvas.height); }

  function pos(e) {
    const r = canvas.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  }

  function onDown(e) {
    drawing = true;
    const p = pos(e);
    sx = p.x; sy = p.y;
    snap = ctx.getImageData(0, 0, canvas.width, canvas.height);

    if (tool === 'pen' || tool === 'eraser') {
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      applyStyle();
    }
  }

  function onMove(e) {
    if (!drawing) return;
    const p = pos(e);

    if (tool === 'pen' || tool === 'eraser') {
      applyStyle();
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
      _emitDraw && _emitDraw({ tool, color, size, x1:sx, y1:sy, x2:p.x, y2:p.y });
      sx = p.x; sy = p.y;
    } else {
      ctx.putImageData(snap, 0, 0);
      drawShape(tool, sx, sy, p.x, p.y);
    }
  }

  function onUp(e) {
    if (!drawing) return;
    drawing = false;
    if (e && (tool==='line'||tool==='rect'||tool==='circle')) {
      const p = pos(e);
      _emitDraw && _emitDraw({ tool, color, size, x1:sx, y1:sy, x2:p.x, y2:p.y });
    }
    save();
    ctx.beginPath();
  }

  function applyStyle() {
    ctx.lineWidth   = tool==='eraser' ? size*4 : size;
    ctx.strokeStyle = tool==='eraser' ? '#ffffff' : color;
    ctx.lineCap     = 'round';
    ctx.lineJoin    = 'round';
  }

  function drawShape(t, x1, y1, x2, y2) {
    ctx.beginPath();
    ctx.strokeStyle = color;
    ctx.lineWidth   = size;
    ctx.lineCap     = 'round';
    if (t==='line')   { ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); }
    else if (t==='rect')   { ctx.strokeRect(x1, y1, x2-x1, y2-y1); }
    else if (t==='circle') {
      const r = Math.hypot(x2-x1, y2-y1);
      ctx.arc(x1, y1, r, 0, Math.PI*2);
    }
    ctx.stroke();
  }

  /* ── remote draw (called from room.js) ─ */
  function applyRemote(d) {
    const prev = { strokeStyle:ctx.strokeStyle, lineWidth:ctx.lineWidth };
    if (d.tool==='pen' || d.tool==='eraser') {
      ctx.beginPath();
      ctx.moveTo(d.x1, d.y1);
      ctx.lineTo(d.x2, d.y2);
      ctx.strokeStyle = d.tool==='eraser' ? '#ffffff' : d.color;
      ctx.lineWidth   = d.tool==='eraser' ? d.size*4  : d.size;
      ctx.lineCap     = 'round';
      ctx.lineJoin    = 'round';
      ctx.stroke();
    } else {
      ctx.strokeStyle = d.color;
      ctx.lineWidth   = d.size;
      drawShape(d.tool, d.x1, d.y1, d.x2, d.y2);
    }
    ctx.strokeStyle = prev.strokeStyle;
    ctx.lineWidth   = prev.lineWidth;
  }

  function save() {
    history.push(ctx.getImageData(0, 0, canvas.width, canvas.height));
    if (history.length > 60) history.shift();
  }

  /* ── public API ─────────────────────── */
  function setTool(t)  { tool  = t; }
  function setColor(c) { color = c; }
  function setSize(s)  { size  = parseInt(s, 10); }

  function undo() {
    if (history.length > 1) {
      history.pop();
      ctx.putImageData(history[history.length-1], 0, 0);
      _emitUndo && _emitUndo();
    }
  }

  function clear() {
    fill('#ffffff');
    history = [];
    save();
    _emitClear && _emitClear();
  }

  function savePng() {
    const a = document.createElement('a');
    a.download = 'whiteboard.png';
    a.href     = canvas.toDataURL();
    a.click();
  }

  return { init, applyRemote, setTool, setColor, setSize, undo, clear, savePng };
})();

/* ── Toolbar helpers called from HTML ── */
function wbTool(t) {
  Whiteboard.setTool(t);
  document.querySelectorAll('.tb-btn').forEach(b => b.classList.remove('active'));
  const el = document.getElementById('tb-'+t);
  if (el) el.classList.add('active');
}
function wbUndo()  { Whiteboard.undo(); }
function wbClear() { if (confirm('Clear the whiteboard for everyone?')) Whiteboard.clear(); }
function wbSave()  { Whiteboard.savePng(); }

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('wb-color')?.addEventListener('input', e => Whiteboard.setColor(e.target.value));
  document.getElementById('wb-size')?.addEventListener('input', e => {
    Whiteboard.setSize(e.target.value);
    document.getElementById('wb-size-label').textContent = e.target.value + 'px';
  });
});
