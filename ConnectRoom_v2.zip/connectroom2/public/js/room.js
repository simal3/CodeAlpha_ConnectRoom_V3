/**
 * ConnectRoom — Room Logic (v2)
 * Fixed:
 *  - WebRTC offer/answer race condition (polite-peer pattern)
 *  - ICE candidates queued until remote desc set
 *  - Screen share track replacement in all peers
 *  - Whiteboard init after socket ready
 *  - Encryption toggle + key autogen
 *  - Panel tab switching
 *  - File upload with progress feedback
 *  - All socket event names match server exactly
 */

'use strict';

// ── State ─────────────────────────────────────────────────────
let socket       = null;
let localStream  = null;   // camera+mic
let screenStream = null;   // screen share
let me           = null;   // { id, username, displayName }
let roomId       = null;
let roomName     = '';

let micOn    = true;
let camOn    = true;
let screenOn = false;
let wbOn     = false;
let panelOn  = true;

// WebRTC
// peers: socketId → { pc: RTCPeerConnection, iceBuf: [], makingOffer: bool, polite: bool }
const peers = new Map();

const ICE_CONFIG = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
  ]
};

// Encryption
let encEnabled = false;
let encKey     = '';

// Unread badge
let unread = 0;

// ── Entry point ───────────────────────────────────────────────
async function boot() {
  // 1. Verify auth
  const r = await fetch('/api/me');
  if (!r.ok) { location.href='/'; return; }
  const { user } = await r.json();
  if (!user)     { location.href='/'; return; }
  me = user;

  // 2. Get room id from URL
  roomId = location.pathname.split('/').pop().toUpperCase();

  // 3. Check room exists
  const rr = await fetch('/api/rooms/' + roomId);
  if (!rr.ok) { toast('Room not found.','error'); setTimeout(()=>location.href='/dashboard',2000); return; }
  const { room } = await rr.json();
  roomName = room.name;
  document.getElementById('room-name-el').textContent = room.name;
  document.getElementById('room-code-el').textContent = 'Code: ' + roomId;
  document.title = room.name + ' – ConnectRoom';

  // 4. Get local media (non-fatal)
  await initMedia();

  // 5. Render local tile
  addLocalTile();

  // 6. Connect socket
  connectSocket();
}

// ── Media ─────────────────────────────────────────────────────
async function initMedia() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
  } catch (err) {
    console.warn('getUserMedia failed:', err.name, err.message);
    localStream = new MediaStream();  // empty — user can still chat / whiteboard
    toast('Camera/mic not available. Chat and whiteboard still work.','error');
    micOn = false; camOn = false;
    updateCtrlBtn('ctrl-mic', false);
    updateCtrlBtn('ctrl-cam', false);
  }
}

function addLocalTile() {
  const grid = document.getElementById('video-grid');
  grid.innerHTML = '';   // clear any stale tiles

  const tile = makeTile('local', me.displayName, true);
  const vid  = tile.querySelector('video');
  if (localStream.getVideoTracks().length) {
    vid.srcObject = localStream;
    tile.querySelector('.no-vid').style.display = 'none';
  }
  grid.appendChild(tile);
  updatePeerChips();
}

function makeTile(id, label, isLocal) {
  const div = document.createElement('div');
  div.className = 'vid-tile';
  div.id        = 'tile-' + id;
  div.innerHTML = `
    <video autoplay playsinline ${isLocal?'muted':''}></video>
    <div class="vid-label">${esc(label)}${isLocal?' (You)':''}</div>
    <div class="no-vid"><div class="av-initial">${label[0].toUpperCase()}</div></div>`;
  return div;
}

function esc(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// ── Socket.io ─────────────────────────────────────────────────
function connectSocket() {
  socket = io({ transports: ['websocket','polling'] });

  socket.on('connect', () => {
    setBadge('connected');
    socket.emit('join-room', { roomId });

    // Init whiteboard emitters now that socket exists
    Whiteboard.init(
      document.getElementById('wb-canvas'),
      data  => socket.emit('wb-draw',  { roomId, data }),
      ()    => socket.emit('wb-clear', { roomId }),
      ()    => socket.emit('wb-undo',  { roomId })
    );
  });

  socket.on('disconnect', () => setBadge('disconnected'));
  socket.on('connect_error', () => setBadge('disconnected'));

  socket.on('auth-error', ({ message }) => { toast(message,'error'); setTimeout(()=>location.href='/',2000); });
  socket.on('room-error', ({ message }) => { toast(message,'error'); setTimeout(()=>location.href='/dashboard',2000); });

  // ── Room joined ──────────────────────────────────────────────
  socket.on('room-joined', ({ participants, messages, files }) => {
    // Render existing chat history
    messages.forEach(m => renderMsg(m));
    // Render existing files
    files.forEach(f => renderFile(f));
    // Render existing participants list
    renderPeerList(participants);
    // Initiate WebRTC with each existing participant
    participants.forEach(p => {
      addRemoteTile(p.socketId, p.displayName);
      startPeerConnection(p.socketId, true);   // we are the polite newcomer → NOT polite=false for existing
    });
    updatePeerChips();
  });

  // ── Peer joined ──────────────────────────────────────────────
  socket.on('peer-joined', ({ socketId, displayName }) => {
    toast(displayName + ' joined the room');
    addRemoteTile(socketId, displayName);
    startPeerConnection(socketId, false);   // existing peer = impolite (they will offer)
    addToPeerList(socketId, displayName);
    updatePeerChips();
  });

  // ── Peer left ────────────────────────────────────────────────
  socket.on('peer-left', ({ socketId, displayName }) => {
    toast(displayName + ' left');
    closePeer(socketId);
    document.getElementById('tile-'+socketId)?.remove();
    document.getElementById('pi-'+socketId)?.remove();
    updatePeerChips();
  });

  // ── WebRTC signalling (perfect negotiation pattern) ──────────
  socket.on('rtc-offer', async ({ from, displayName, offer }) => {
    let peer = peers.get(from);
    if (!peer) {
      peer = startPeerConnection(from, true);   // we are polite if we didn't start
      addRemoteTile(from, displayName);
      addToPeerList(from, displayName);
    }
    const pc = peer.pc;
    const offerCollision = peer.makingOffer || pc.signalingState !== 'stable';
    if (offerCollision && !peer.polite) return;   // impolite peer ignores collision

    await pc.setRemoteDescription(offer);
    // Flush buffered ICE
    for (const c of peer.iceBuf) { try { await pc.addIceCandidate(c); } catch {} }
    peer.iceBuf = [];

    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    socket.emit('rtc-answer', { to: from, answer });
  });

  socket.on('rtc-answer', async ({ from, answer }) => {
    const peer = peers.get(from);
    if (!peer) return;
    try { await peer.pc.setRemoteDescription(answer); } catch {}
    // Flush buffered ICE
    for (const c of peer.iceBuf) { try { await peer.pc.addIceCandidate(c); } catch {} }
    peer.iceBuf = [];
  });

  socket.on('rtc-ice', async ({ from, candidate }) => {
    const peer = peers.get(from);
    if (!peer) return;
    if (peer.pc.remoteDescription) {
      try { await peer.pc.addIceCandidate(candidate); } catch {}
    } else {
      peer.iceBuf.push(candidate);   // buffer until remote desc is set
    }
  });

  // ── Chat ─────────────────────────────────────────────────────
  socket.on('chat-recv', msg => {
    renderMsg(msg);
    // Increment badge if panel hidden or not on chat tab
    const chatSection = document.getElementById('ps-chat');
    if (!panelOn || !chatSection.classList.contains('active')) {
      unread++;
      const t = document.getElementById('pt-chat');
      t.textContent = `💬 Chat (${unread})`;
    }
  });

  // ── Whiteboard ───────────────────────────────────────────────
  socket.on('wb-draw',  ({ data })  => Whiteboard.applyRemote(data));
  socket.on('wb-clear', ()          => Whiteboard.clear());
  socket.on('wb-undo',  ()          => Whiteboard.undo());

  // ── Files ────────────────────────────────────────────────────
  socket.on('file-added', f => {
    renderFile(f);
    toast('📁 ' + f.uploader + ' shared: ' + f.name);
  });

  // ── Peer media state ─────────────────────────────────────────
  socket.on('peer-media', ({ socketId, audio, video }) => {
    const tile = document.getElementById('tile-'+socketId);
    if (!tile) return;
    const noVid = tile.querySelector('.no-vid');
    if (noVid) noVid.style.display = video ? 'none' : 'flex';
  });
}

// ── WebRTC peer connection ────────────────────────────────────
function startPeerConnection(targetId, polite) {
  // Clean up any existing connection
  closePeer(targetId);

  const pc = new RTCPeerConnection(ICE_CONFIG);
  const peer = { pc, iceBuf: [], makingOffer: false, polite };
  peers.set(targetId, peer);

  // Add local tracks
  if (localStream) {
    localStream.getTracks().forEach(t => pc.addTrack(t, localStream));
  }

  // ICE candidates → relay via server
  pc.onicecandidate = ({ candidate }) => {
    if (candidate) socket.emit('rtc-ice', { to: targetId, candidate });
  };

  pc.onconnectionstatechange = () => {
    console.log(`[WebRTC] ${targetId} → ${pc.connectionState}`);
  };

  // Remote track → show in tile
  pc.ontrack = ({ streams }) => {
    const tile = document.getElementById('tile-'+targetId);
    if (!tile) return;
    const vid  = tile.querySelector('video');
    vid.srcObject = streams[0];
    tile.querySelector('.no-vid').style.display = 'none';
  };

  // Negotiation needed (fires when tracks added or renegotiating)
  pc.onnegotiationneeded = async () => {
    try {
      peer.makingOffer = true;
      const offer = await pc.createOffer();
      if (pc.signalingState !== 'stable') return;   // aborted
      await pc.setLocalDescription(offer);
      socket.emit('rtc-offer', { to: targetId, offer: pc.localDescription });
    } catch (e) {
      console.error('onnegotiationneeded error', e);
    } finally {
      peer.makingOffer = false;
    }
  };

  return peer;
}

function closePeer(id) {
  const peer = peers.get(id);
  if (peer) { try { peer.pc.close(); } catch {} peers.delete(id); }
}

// ── Tile helpers ──────────────────────────────────────────────
function addRemoteTile(socketId, displayName) {
  if (document.getElementById('tile-'+socketId)) return;
  const tile = makeTile(socketId, displayName, false);
  document.getElementById('video-grid').appendChild(tile);
}

// ── Controls ──────────────────────────────────────────────────
function toggleMic() {
  micOn = !micOn;
  localStream?.getAudioTracks().forEach(t => t.enabled = micOn);
  updateCtrlBtn('ctrl-mic', micOn, '🎤','🔇', 'Mute','Unmute');
  emitMediaState();
}

function toggleCam() {
  camOn = !camOn;
  localStream?.getVideoTracks().forEach(t => t.enabled = camOn);
  updateCtrlBtn('ctrl-cam', camOn, '📷','📵', 'Cam','No Cam');
  const noVid = document.querySelector('#tile-local .no-vid');
  if (noVid) noVid.style.display = camOn ? 'none' : 'flex';
  emitMediaState();
}

async function toggleScreen() {
  if (!screenOn) {
    try {
      screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: true });
      const track  = screenStream.getVideoTracks()[0];

      // Replace cam track in all peer connections
      peers.forEach(({ pc }) => {
        const sender = pc.getSenders().find(s => s.track?.kind === 'video');
        if (sender) sender.replaceTrack(track).catch(()=>{});
      });

      // Show own screen in local tile
      const vid = document.querySelector('#tile-local video');
      if (vid) vid.srcObject = screenStream;

      track.onended = () => { screenOn = true; toggleScreen(); };  // user stopped via browser UI

      screenOn = true;
      updateCtrlBtn('ctrl-screen', false, '⏹️','🖥️', 'Stop','Share');
      document.getElementById('ctrl-screen').classList.add('on');
      toast('Screen sharing started');
    } catch (e) {
      if (e.name !== 'NotAllowedError') toast('Screen sharing failed: ' + e.message,'error');
    }
  } else {
    screenStream?.getTracks().forEach(t => t.stop());
    screenStream = null;

    // Restore camera track
    const camTrack = localStream?.getVideoTracks()[0];
    peers.forEach(({ pc }) => {
      const sender = pc.getSenders().find(s => s.track?.kind === 'video');
      if (sender && camTrack) sender.replaceTrack(camTrack).catch(()=>{});
    });

    const vid = document.querySelector('#tile-local video');
    if (vid) vid.srcObject = localStream;

    screenOn = false;
    updateCtrlBtn('ctrl-screen', false, '🖥️','⏹️','Share','Stop');
    document.getElementById('ctrl-screen').classList.remove('on');
    toast('Screen sharing stopped');
  }
}

function toggleWb() {
  wbOn = !wbOn;
  const wrap = document.getElementById('wb-wrap');
  const grid = document.getElementById('video-grid');
  wrap.style.display = wbOn ? 'flex' : 'none';
  grid.style.display = wbOn ? 'none' : 'grid';
  document.getElementById('ctrl-wb').classList.toggle('on', wbOn);
}

function togglePanel() {
  panelOn = !panelOn;
  document.getElementById('side-panel').style.display = panelOn ? 'flex' : 'none';
  document.getElementById('ctrl-panel').classList.toggle('on', panelOn);
}

function updateCtrlBtn(id, isOn, onIcon, offIcon, onLabel, offLabel) {
  const btn = document.getElementById(id);
  if (!btn) return;
  btn.querySelector('.ci').textContent = isOn ? (onIcon||'') : (offIcon||'');
  btn.querySelector('.cl').textContent = isOn ? (onLabel||'') : (offLabel||'');
  btn.classList.toggle('off', !isOn);
}

function emitMediaState() {
  if (socket && roomId) {
    socket.emit('media-update', { roomId, audio: micOn, video: camOn, screen: screenOn });
  }
}

// ── Chat ──────────────────────────────────────────────────────
function onChatKey(e) { if (e.key==='Enter') sendMsg(); }

async function sendMsg() {
  const inp  = document.getElementById('chat-in');
  const text = inp.value.trim();
  if (!text) return;
  inp.value = '';

  let payload = text;
  let encrypted = false;

  if (encEnabled && encKey) {
    const cipher = await Crypto.encrypt(text, encKey);
    if (!cipher) { toast('Encryption failed','error'); return; }
    payload   = cipher;
    encrypted = true;
  }

  socket.emit('chat-send', { roomId, text: payload, encrypted });
}

async function renderMsg(msg) {
  const list = document.getElementById('msg-list');
  const own  = msg.username === me.username;
  let display = msg.text;

  if (msg.encrypted) {
    display = encEnabled && encKey
      ? await Crypto.decrypt(msg.text, encKey)
      : '🔒 Encrypted message';
  }

  const time = new Date(msg.ts).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
  const el   = document.createElement('div');
  el.className = 'msg' + (own?' own':'');
  el.innerHTML = `
    ${!own ? `<div class="msg-sender">${esc(msg.sender)}</div>` : ''}
    <div class="msg-bubble${msg.encrypted?' enc':''}">
      ${msg.encrypted?'<span class="enc-tag">🔒</span>':''}${esc(display)}
    </div>
    <div class="msg-time">${time}</div>`;
  list.appendChild(el);
  list.scrollTop = list.scrollHeight;
}

function onEncToggle() {
  encEnabled = document.getElementById('enc-chk').checked;
  const kw   = document.getElementById('enc-key-wrap');
  kw.style.display = encEnabled ? 'flex' : 'none';
  if (encEnabled && !document.getElementById('enc-key').value) {
    const k = Crypto.generateKey();
    document.getElementById('enc-key').value = k;
    encKey = k;
    toast('🔒 Encryption key auto-generated. Share it with your peers!','success');
  }
}

function copyEncKey() {
  const k = document.getElementById('enc-key').value;
  if (!k) return;
  navigator.clipboard.writeText(k).then(()=>toast('Encryption key copied!','success'));
}

// ── Participants ──────────────────────────────────────────────
function renderPeerList(participants) {
  const list = document.getElementById('peer-list');
  list.innerHTML = `
    <div class="pi" id="pi-local">
      <div class="pi-av">${me.displayName[0].toUpperCase()}</div>
      <div class="pi-info"><b>${esc(me.displayName)}</b><small>You</small></div>
    </div>`;
  participants.forEach(p => addToPeerList(p.socketId, p.displayName));
}

function addToPeerList(socketId, displayName) {
  if (document.getElementById('pi-'+socketId)) return;
  const list = document.getElementById('peer-list');
  const el   = document.createElement('div');
  el.className='pi'; el.id='pi-'+socketId;
  el.innerHTML=`<div class="pi-av">${displayName[0].toUpperCase()}</div><div class="pi-info"><b>${esc(displayName)}</b></div>`;
  list.appendChild(el);
}

function updatePeerChips() {
  const all = [me.displayName, ...[...document.querySelectorAll('.pi:not(#pi-local) .pi-info b')].map(b=>b.textContent)];
  document.getElementById('peer-chips').innerHTML =
    all.slice(0,5).map(n=>`<div class="chip" title="${esc(n)}">${n[0].toUpperCase()}</div>`).join('') +
    (all.length>5 ? `<div class="chip more">+${all.length-5}</div>` : '');
}

// ── File sharing ──────────────────────────────────────────────
async function uploadFile(file) {
  if (!file) return;
  if (file.size > 50*1024*1024) { toast('File too large (max 50 MB)','error'); return; }
  toast('Uploading ' + file.name + '…');
  const fd = new FormData();
  fd.append('file', file);
  try {
    const r = await fetch(`/api/rooms/${roomId}/upload`,{method:'POST',body:fd});
    const d = await r.json();
    if (!r.ok) { toast(d.error,'error'); return; }
    toast('✅ ' + file.name + ' uploaded!','success');
    // file-added socket event will call renderFile
  } catch { toast('Upload failed','error'); }
}

function onFileDrop(e) {
  e.preventDefault();
  const f = e.dataTransfer.files[0];
  if (f) uploadFile(f);
}

function renderFile(f) {
  if (document.getElementById('file-'+f.id)) return; // deduplicate
  const list = document.getElementById('file-list');
  const kb   = f.size > 1048576 ? (f.size/1048576).toFixed(1)+' MB' : Math.round(f.size/1024)+' KB';
  const icon = f.mimeType?.startsWith('image') ? '🖼️' : f.mimeType?.startsWith('video') ? '🎬' : f.mimeType?.includes('pdf') ? '📄' : '📁';
  const el   = document.createElement('div');
  el.className='fi'; el.id='file-'+f.id;
  el.innerHTML=`
    <span class="fi-icon">${icon}</span>
    <div class="fi-info">
      <div class="fi-name" title="${esc(f.name)}">${esc(f.name)}</div>
      <div class="fi-meta">${kb} · ${esc(f.uploader)}</div>
    </div>
    <a href="/api/rooms/${roomId}/files/${f.id}" download="${esc(f.name)}" class="btn-dl">⬇️</a>`;
  list.appendChild(el);
}

// ── Panel tab switching ───────────────────────────────────────
function switchTab(name) {
  ['chat','participants','files'].forEach(n => {
    document.getElementById('pt-'+n).classList.toggle('active', n===name);
    document.getElementById('ps-'+n).classList.toggle('active', n===name);
  });
  if (name==='chat') {
    unread=0;
    document.getElementById('pt-chat').textContent='💬 Chat';
    document.getElementById('msg-list').scrollTop = 999999;
  }
}

// ── Misc ──────────────────────────────────────────────────────
function setBadge(state) {
  const el = document.getElementById('conn-badge');
  el.className = 'conn-badge ' + state;
  el.textContent = state==='connected' ? '● Connected' : '● Disconnected';
}

function toast(msg, type='') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className   = 'toast show ' + type;
  clearTimeout(t._tid);
  t._tid = setTimeout(()=>{ t.className='toast'; }, 3500);
}

function leaveRoom() {
  localStream?.getTracks().forEach(t=>t.stop());
  screenStream?.getTracks().forEach(t=>t.stop());
  socket?.disconnect();
  location.href='/dashboard';
}

// ── Boot ──────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', boot);
window.addEventListener('beforeunload', leaveRoom);
