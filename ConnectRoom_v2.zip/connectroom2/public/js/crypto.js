/**
 * AES-256-GCM encryption using the browser's built-in Web Crypto API.
 * No external library needed.
 */
const Crypto = (() => {
  const ENC = new TextEncoder();
  const DEC = new TextDecoder();

  /** Derive a 256-bit AES-GCM key from a password string */
  async function deriveKey(password) {
    const raw = await crypto.subtle.importKey(
      'raw', ENC.encode(password), 'PBKDF2', false, ['deriveKey']
    );
    return crypto.subtle.deriveKey(
      { name: 'PBKDF2', salt: ENC.encode('cr-salt-v2'), iterations: 120000, hash: 'SHA-256' },
      raw,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  /**
   * Encrypt plaintext → base64 string  (iv prepended)
   * Returns null on failure.
   */
  async function encrypt(plaintext, password) {
    try {
      const key        = await deriveKey(password);
      const iv         = crypto.getRandomValues(new Uint8Array(12));
      const cipherBuf  = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, ENC.encode(plaintext));
      const combined   = new Uint8Array(12 + cipherBuf.byteLength);
      combined.set(iv);
      combined.set(new Uint8Array(cipherBuf), 12);
      return btoa(String.fromCharCode(...combined));
    } catch {
      return null;
    }
  }

  /**
   * Decrypt base64 ciphertext → plaintext string
   * Returns an error marker string on wrong key / tampered data.
   */
  async function decrypt(cipherB64, password) {
    try {
      const bytes     = Uint8Array.from(atob(cipherB64), c => c.charCodeAt(0));
      const iv        = bytes.slice(0, 12);
      const cipher    = bytes.slice(12);
      const key       = await deriveKey(password);
      const plainBuf  = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, cipher);
      return DEC.decode(plainBuf);
    } catch {
      return '🔒 [Cannot decrypt — wrong key]';
    }
  }

  /** Generate a random 18-char secret key string */
  function generateKey() {
    const chars = 'ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#';
    return Array.from(crypto.getRandomValues(new Uint8Array(18)))
                .map(b => chars[b % chars.length]).join('');
  }

  return { encrypt, decrypt, generateKey };
})();
