# 🎥 ConnectRoom v2 — Real-Time Video Collaboration
### CodeAlpha Full Stack Internship — Task 4 (Fixed)

---

## ✅ What Was Fixed in v2

| Bug | Fix |
|-----|-----|
| WebRTC offer/answer race condition | Implemented **perfect negotiation** pattern with polite/impolite peers |
| ICE candidates arriving before remote description | **ICE candidate buffering** until remote desc is set |
| Screen share breaking peer connections | Proper **track replacement** via `RTCRtpSender.replaceTrack()` |
| Socket event name mismatch (client vs server) | All events now match: `rtc-offer`, `rtc-answer`, `rtc-ice`, `chat-send/recv`, `wb-draw/clear/undo`, `file-added` |
| Whiteboard initialized before socket was ready | Whiteboard init moved **inside `socket.on('connect')`** |
| Panel tab switching broken | Rewrote tab logic with proper CSS class toggling |
| File download broken | Fixed route auth + proper Content-Disposition header |
| Session not shared with Socket.io properly | Fixed `sessionMW` passing `{}` as res object |
| Encryption key not persisted | `encKey` variable properly tracked via `oninput` |

---

## 🗂️ File Structure

```
CodeAlpha_ConnectRoom/
├── server.js              ← Express + Socket.io backend (ALL logic here)
├── package.json
└── public/
    ├── index.html         ← Login / Register page
    ├── dashboard.html     ← Create / Join rooms
    ├── room.html          ← Conference room UI
    ├── css/
    │   └── style.css      ← Styles for all 3 pages
    └── js/
        ├── crypto.js      ← AES-256-GCM encryption (Web Crypto API)
        ├── whiteboard.js  ← Canvas drawing + sync
        └── room.js        ← WebRTC, Socket.io, all room logic
```

**Which file does what:**
- `server.js` → HTTP routes (auth, rooms, file upload/download) + Socket.io signalling server
- `crypto.js` → Browser-side AES-256 GCM encryption, no external library
- `whiteboard.js` → Canvas drawing engine + emits draw events via socket
- `room.js` → All WebRTC peer connections, chat, file sharing, UI controls

---

## 🚀 Step-by-Step Setup

### Step 1 — Install Node.js
Download from https://nodejs.org (version 16 or higher)

Verify:
```bash
node --version   # should print v16.x or higher
npm --version
```

### Step 2 — Extract the zip
```
Unzip ConnectRoom.zip to a folder, e.g. C:\Projects\ConnectRoom
```

### Step 3 — Open terminal in the project folder
```bash
cd path/to/ConnectRoom
```

### Step 4 — Install dependencies
```bash
npm install
```
This installs: express, socket.io, bcryptjs, express-session, multer, uuid

### Step 5 — Start the server
```bash
npm start
```

You should see:
```
======================================
  ConnectRoom  →  http://localhost:3000
  Demo: alice/demo1234  |  bob/demo1234
======================================
```

### Step 6 — Open in browser
```
http://localhost:3000
```

---

## 🧪 How to Test All Features

### Test Video Calling
1. Open two browser tabs (or two different browsers)
2. Login as `alice` in one, `bob` in the other
3. In alice's tab: Create a Room → note the 6-char room code
4. In bob's tab: Dashboard → enter the room code → Join Room
5. Both should see each other's video feed

### Test Screen Sharing
1. Inside a room, click **🖥️ Share**
2. Browser will ask which screen/window to share
3. Your screen appears in your local tile
4. Other participants see your screen

### Test Encrypted Chat
1. Open the Chat panel
2. Toggle **🔒 Encrypt** ON
3. A key is auto-generated — copy it
4. Share the key with the other participant (paste it in their enc key field)
5. Send messages — they appear with a 🔒 badge
6. Without the correct key, messages show "[Cannot decrypt]"

### Test Whiteboard
1. Click **🎨 Board** to open whiteboard
2. Draw with pen, shapes, etc.
3. Other participants see drawing in real-time
4. Click 💾 to save as PNG

### Test File Sharing
1. Open **📁 Files** panel
2. Click the drop zone or drag a file
3. File uploads and notifies all participants
4. Others can click ⬇️ to download

---

## 👤 Demo Accounts
Pre-created automatically when server starts:

| Username | Password |
|----------|----------|
| alice    | demo1234 |
| bob      | demo1234 |

You can also register new accounts.

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Backend | Node.js + Express.js |
| Real-Time | Socket.io v4 |
| Video/Audio | WebRTC (RTCPeerConnection, perfect negotiation) |
| Encryption | Web Crypto API — AES-256-GCM + PBKDF2 |
| Auth | express-session + bcryptjs |
| File Upload | Multer (memory storage) |
| Whiteboard | HTML5 Canvas API |
| Frontend | Vanilla HTML + CSS + JavaScript |

---

## ⚠️ Notes
- Camera/mic require **HTTPS** in production (localhost is exempt)
- For calls across different networks, you need a **TURN server** (coturn)
- Files are stored in memory — they reset when the server restarts
- Rooms are also in-memory — add a database for persistence
